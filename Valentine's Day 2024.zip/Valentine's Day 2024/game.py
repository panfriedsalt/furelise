# Name and ID: Calvin Pan, nqc8gh

# Checkpoint 1 comments below
# Description of game: The game's title will be "Trivia Tower."
# This game will allow the player to build a sky-high tower of blocks.
# Players gain blocks by answering a trivia question (e.g. "What is the capital of Azerbaijian?")
# correctly, and lose blocks by answering them wrongly. The end goal is to build your tower of blocks
# as high as possible (or just avoid having 0 blocks, which ends the game) within a set time period:
# players can choose 5 or 10 minutes.

# Basic feature 1: User input: The player will select a choice for an answer to a question
# using their mouse.
# Basic feature 2: Game over: Player "loses" the game by either reaching 0 blocks or having time
# reach 0.
# Basic feature 3: Graphics: The blocks will be multicolored and the answer prompts will be
# specially designed as well. Additionally, there will be background art and perhaps other
# characters to the side (that do not impact the gameplay) to make the game visually appealing.

# Additional feature 1: Object oriented code: Classes will be made for the blocks,
# question text, and answer prompts to better facilitate their functionality within the game.
# Methods will be created for said classes.
# Additional feature 2: Restart from game over: Players will be able to restart the game if
# either time runs out or they reach 0 blocks by pressing a button. Both the start game dialog
# and the restart dialog will allow the player to select a certain number of minutes.
# Additional feature 3: Health bar: The player's block tower height will be graphically
# displayed as a health bar on screen, with it increasing with tower height and decreasing
# until it reaches 0 (in which case the player's game ends)
# Additional feature 4: Timer: The player will have timers for both each question (20 seconds
# to respond) and for the game as a whole (5 or 10 minutes)
# Additional feature 5: Scrolling level: The player's block tower will be taller than the screen
# itself, and players can see the whole tower by pressing keys up arrow and down arrow to explore
# it.

# Checkpoint 2 code below
import uvage
import random

# Screen definition
screen_width = 800
screen_height = 600
camera = uvage.Camera (screen_width, screen_height)

# Background & rendered objects
background_color = "lightpink2"
render_list = []
boundaries_list = []
do_not_move_list = []
background_list = []

# Boundaries of screen (to ensure that blocks do not fall out of screen)
lower_boundary = uvage.from_color (screen_width/2, screen_height + 5000, "brown", screen_width + 10, 10000)
boundaries_list.append(lower_boundary)
left_boundary = uvage.from_color (-50, screen_height/2, "dodgerblue3", 100, screen_height + 10)
boundaries_list.append(left_boundary)
right_boundary = uvage.from_color (screen_width +50 , screen_height/2, "dodgerblue3", 100, screen_height + 10)
boundaries_list.append(right_boundary)

# Constants
fps = 30 # Frames per second
checkquestiontimes = 10 # How many times a second the game will check for an answer
checkquestionframes = fps / checkquestiontimes # Game will check for an answer every x frames
scroll_speed = 20 # Pixels/second the screen scrolls up/down when the player presses the up or down arrows
starting_health = 2 # How many blocks aka how much health the player starts with
block_height = 50 # How tall blocks will be
block_width = 200 # How wide blocks will be
gravity = 1 # How fast created blocks will be dropped from a given generation point onto the tower of blocks
startquestionid = random.randint(0, 47) # The id of the question that the game will start with
currentquestion = [] # Create an empty list for current question to start in
currentquestionid = startquestionid
starttotaltime = 300 # Total time a player gets to answer a question
timeperquestion = 20 # Amount of time the user gets to answer each question
answer_choices = 4 # Number of answer choices the player will have to choose from (set this as either 2 or 4)
postrackery = 0 # Records how much the camera has moved in a given direction and modifies the positions of objects accordingly

# Import questions list & format questions as dictionary
questions_dict = {}
with open("questions_edited.txt", "r") as infile:
    lines = infile.readlines() # Opens the questions file and reads all the lines

num_lines = len(lines)
idofquestion = 0 # Sets up question numbering so that each question gets a unique ID
count = 0 # Sets up a loop that repeats every 6 lines (one full question)
while count < num_lines:
    question1 = lines[count].strip()
    question2 = ""
    if len(question1) > 60:
        question1new = question1
        for x in question1new[60:]:
            if x == " ":
                spacechecker = question1new[60:].index(x)
            else:
                spacechecker = 60
        question1 = question1 [0:spacechecker]
        question2 = question1new [spacechecker:]
    answers = [lines[i].strip() for i in range(count + 1, count + 5)]
    right_answer =  lines[count + 5].strip()
    answers_1 = [question1, question2, answers, right_answer]
    questions_dict[idofquestion] = answers_1
    # Stores questions in a specific dictionary format
    # with the question as the key and answers as a list.
    # The answer choices are stored as a sublist and the correct answer is stored as a separate item
    count += 6
    idofquestion += 1

numofquestions = len(questions_dict) # Variable to store how many questions there are

# Block class definition
blocks = {}
class Block:
    def __init__(self):
    # Assign each block an unique ID
        blockids = list(blocks.keys())
        blockids.sort()
        if blockids == []:
            id = 0
        else:
            lastid = blockids[-1]
            id = (int(lastid) + 1)
        self.__id = id
    # Figure out the generation location of the block from the ID
        xpos = screen_width/2
        ypos = (screen_height-block_height)-(self.__id * block_height)
    # Generate the block
        block = uvage.from_image(xpos, ypos, "Stone Block Texture.jpeg") # Placeholder texture, may make a new one
        self.__block = block
    # Rescale the block
        self.__block.size = [block_width, block_height]
    # Add block to various lists
        blocks[self.__id] = self.__block
        boundaries_list.append(self.__block)
    # Give each block a move speed
        self.__block.speedx = 0
        self.__block.speedy = 0

    def delete_block(self):
        del blocks[self.__id]
        boundaries_list.remove(self.__block)

    def lock_block_movement(self):
        do_not_move_list.append(self.__block)

# Health bar
health = starting_health
health_bar = uvage.from_color(30, 45 + postrackery, "red", health, 20)
render_list.append (health_bar)
do_not_move_list.append(health_bar)
health_bar_overlay = uvage.from_image(90, 50 + postrackery, "Empty Health Bar.png")
health_bar_overlay.width = 175
render_list.append(health_bar_overlay)
do_not_move_list.append(health_bar_overlay)
health_text = uvage.from_text(70, 20 + postrackery, "Health: " + str(health), 20, "red")
render_list.append(health_text)
do_not_move_list.append(health_text)

def healthtick():
    health = len(blocks)
    global health_text # Updates health text first
    render_list.remove(health_text)
    do_not_move_list.remove(health_text)
    health_text = uvage.from_text(60, 20 + postrackery, "Health: " + str(health), 30, "red")
    render_list.append(health_text)
    do_not_move_list.append(health_text)
    global health_bar # Updates health bar next
    render_list.remove(health_bar)
    do_not_move_list.remove(health_bar)
    health_bar = uvage.from_color(30 + health/2, 45 + postrackery, "red", health, 20)
    render_list.append(health_bar)
    do_not_move_list.append(health_bar)
    global health_bar_overlay  # Updates health bar overlay
    render_list.remove(health_bar_overlay)
    do_not_move_list.remove(health_bar_overlay)
    health_bar_overlay = uvage.from_image(90, 50 + postrackery, "Empty Health Bar.png")
    health_bar_overlay.width = 175
    render_list.append(health_bar_overlay)
    do_not_move_list.append(health_bar_overlay)
    return health

# Score, or final tower height
score = starting_health
score_text = uvage.from_text(screen_width - 90, 20 + postrackery, "Tower height: " + str(score), 30, "white")
render_list.append(score_text)
do_not_move_list.append(score_text)
def scoretick():
    global score
    global score_text
    render_list.remove(score_text)
    do_not_move_list.remove(score_text)
    score_text = uvage.from_text(screen_width - 90, 20 + postrackery, "Tower height: " + str(score), 30, "white")
    do_not_move_list.append(score_text)
    render_list.append(score_text)

# Question class definition
class Question:
    def __init__(self, questionid):
        # Retrieve the current question and its corresponding answers from questions_dict
        self.__questionid = questionid
        qtext1 = questions_dict[self.__questionid][0]
        self.__qtext1 = qtext1
        qtext2 = questions_dict[self.__questionid][1]
        self.__qtext2 = qtext2
        qanswers = questions_dict[self.__questionid][2]
        self.__qanswers = qanswers
        qcorrect = questions_dict[self.__questionid][3]
        self.__qcorrect = qcorrect

        # Create game box for question text background
        qtextbox = uvage.from_color (screen_width/2, 85 + postrackery, "white", screen_width, 50)
        self.__qtextbox = qtextbox
        render_list.append (self.__qtextbox)
        do_not_move_list.append(self.__qtextbox)
        # Create game boxes for question text
        qtext1render = uvage.from_text (screen_width/2, 85 + postrackery, str(self.__qtext1), 20,"black" )
        self.__qtext1render = (qtext1render)
        render_list.append (self.__qtext1render)
        do_not_move_list.append(self.__qtext1render)
        qtext2render = uvage.from_text(screen_width / 2, 100 + postrackery, str(self.__qtext2), 20, "black")
        self.__qtext2render = (qtext2render)
        render_list.append(self.__qtext2render)
        do_not_move_list.append(self.__qtext2render)

        # Give each answer choice a variable, whether or not it's true, and an "is selected" variable
        qanswer1 = self.__qanswers[0]
        self.__qanswer1 = qanswer1
        if self.__qanswer1 == self.__qcorrect:
            qanswer1true = True
        else:
            qanswer1true = False
        self.__qanswer1true = qanswer1true

        qanswer2 = self.__qanswers[1]
        self.__qanswer2 = qanswer2
        if self.__qanswer2 == self.__qcorrect:
            qanswer2true = True
        else:
            qanswer2true = False
        self.__qanswer2true = qanswer2true

        qanswer3 = self.__qanswers[2]
        self.__qanswer3 = qanswer3
        if self.__qanswer3 == self.__qcorrect:
            qanswer3true = True
        else:
            qanswer3true = False
        self.__qanswer3true = qanswer3true

        qanswer4 = self.__qanswers[3]
        self.__qanswer4 = qanswer4
        if self.__qanswer4 == self.__qcorrect:
            qanswer4true = True
        else:
            qanswer4true = False
        self.__qanswer4true = qanswer4true

        # Create game boxes for q1
        qa1textbox = uvage.from_color (screen_width / 2 - 142, 140 + postrackery, "beige", screen_width/3.2, 50)
        self.__qa1textbox = qa1textbox
        qa1textrender = uvage.from_text(screen_width / 2 - 142, 140 + postrackery, "A: " + str(self.__qanswer1), 25, "black")
        self.__qa1textrender = qa1textrender
        render_list.append(self.__qa1textbox)
        render_list.append(self.__qa1textrender)
        do_not_move_list.append(self.__qa1textrender)
        do_not_move_list.append(self.__qa1textbox)

        # Create game boxes for q2
        qa2textbox = uvage.from_color(screen_width / 2 + 142, 140 + postrackery, "beige", screen_width / 3.2, 50)
        self.__qa2textbox = qa2textbox
        qa2textrender = uvage.from_text(screen_width / 2 + 142, 140 + postrackery, "B: " + str(self.__qanswer2), 25, "black")
        self.__qa2textrender = qa2textrender
        render_list.append(self.__qa2textbox)
        render_list.append(self.__qa2textrender)
        do_not_move_list.append(self.__qa2textrender)
        do_not_move_list.append(self.__qa2textbox)

        # Create game boxes for q3
        qa3textbox = uvage.from_color(screen_width / 2 - 142, 195 + postrackery, "beige", screen_width / 3.2, 50)
        self.__qa3textbox = qa3textbox
        qa3textrender = uvage.from_text(screen_width / 2 - 142, 195 + postrackery, "C: " + str(self.__qanswer3), 25, "black")
        self.__qa3textrender = qa3textrender
        render_list.append(self.__qa3textbox)
        render_list.append(self.__qa3textrender)
        do_not_move_list.append(self.__qa3textrender)
        do_not_move_list.append(self.__qa3textbox)

        # Create game boxes for q4
        qa4textbox = uvage.from_color(screen_width / 2 + 142, 195 + postrackery, "beige", screen_width / 3.2, 50)
        self.__qa4textbox = qa4textbox
        qa4textrender = uvage.from_text(screen_width / 2 + 142, 195 + postrackery, "D: " + str(self.__qanswer4), 25, "black")
        self.__qa4textrender = qa4textrender
        render_list.append(self.__qa4textbox)
        render_list.append(self.__qa4textrender)
        do_not_move_list.append(self.__qa4textrender)
        do_not_move_list.append(self.__qa4textbox)

        # Selection mechanism
        self.__qanswer1selected = False
        self.__qanswer2selected = False
        self.__qanswer3selected = False
        self.__qanswer4selected = False

        # Create variable to store how many frames the current question has passed without being checked for a keypress
        framessincecheck = 0
        self.__framessincecheck = framessincecheck

    def refresh_question(self, questionid):
        new_question = self.__init__(questionid)
        self.__new_question = new_question
        currentquestion = self.__new_question # I have no idea why making the currentquestion global here
        # breaks the code but it does

    def keypress(self):
        while self.__framessincecheck < checkquestionframes:
            self.__framessincecheck += 1
            return
        if self.__framessincecheck ==  checkquestionframes:
            if uvage.is_pressing("a") == True:
                self.__qanswer1selected = True
            else:
                self.__qanswer1selected = False

            if uvage.is_pressing("b") == True:
                self.__qanswer2selected = True
            else:
                self.__qanswer2selected = False

            if uvage.is_pressing("c") == True:
                self.__qanswer3selected = True
            else:
                self.__qanswer3selected = False

            if uvage.is_pressing("d") == True:
                self.__qanswer4selected = True
            else:
                self.__qanswer4selected = False
            global currentquestionid
            global score
            if self.__qanswer1selected and self.__qanswer1true:
                block3 = Block()
                currentquestionid = random.randint(0, numofquestions-1)
                self.refresh_question(currentquestionid)
                score += 1
            if self.__qanswer1selected and not self.__qanswer1true:
                if len(blocks) != 0:
                    blocks.popitem()
                currentquestionid = random.randint(0, numofquestions-1)
                self.refresh_question(currentquestionid)

            if self.__qanswer2selected and self.__qanswer2true:
                block3 = Block()
                currentquestionid = random.randint(0, numofquestions-1)
                self.refresh_question(currentquestionid)
                score += 1
            if self.__qanswer2selected and not self.__qanswer2true:
                if len(blocks) != 0:
                    blocks.popitem()
                currentquestionid = random.randint(0, numofquestions-1)
                self.refresh_question(currentquestionid)

            if self.__qanswer3selected and self.__qanswer3true:
                block3 = Block()
                currentquestionid = random.randint(0, numofquestions-1)
                self.refresh_question(currentquestionid)
                score += 1
            if self.__qanswer3selected and not self.__qanswer3true:
                if len(blocks) != 0:
                    blocks.popitem()
                currentquestionid = random.randint(0, numofquestions-1)
                self.refresh_question(currentquestionid)

            if self.__qanswer4selected and self.__qanswer4true:
                block3 = Block()
                currentquestionid = random.randint(0, numofquestions-1)
                self.refresh_question(currentquestionid)
                score += 1
            if self.__qanswer4selected and not self.__qanswer4true:
                if len(blocks) != 0:
                    blocks.popitem()
                currentquestionid = random.randint(0, numofquestions-1)
                self.refresh_question(currentquestionid)

# New after Checkpoint 2 below:

# Question Timer
timer_count = 0
add_timer = False
question_time = timeperquestion

timer_box = uvage.from_color(screen_width / 2, 35 + postrackery, "white", 300, 40)
timer_text = uvage.from_text(screen_width / 2, 35 + postrackery, "Question time left: " + str(question_time), 30, "black")
render_list.append(timer_box)
render_list.append(timer_text)
do_not_move_list.append(timer_box)
do_not_move_list.append(timer_text)

def timer_tracker():
    global timer_count
    global add_timer
    if timer_count == fps:
        add_timer = True
        timer_count = 0
    else:
        timer_count += 1
        add_timer = False

def reset_time():
    return uvage.is_pressing("a") or uvage.is_pressing("b") or uvage.is_pressing("c") or uvage.is_pressing("d")

def questiontimer():
    global add_timer
    global question_time
    global timer_text
    global timer_box
    global health
    global currentquestion

    if reset_time():
        question_time = timeperquestion
    else:
        if add_timer:
            if question_time > 0:  # Ensure the timer doesn't go below 0
                question_time -= 1
            if question_time == 0:
                if len(blocks) != 0:
                    blocks.popitem()
                currentquestion.refresh_question(random.randint(0, numofquestions)-1)
                question_time = timeperquestion

    render_list.remove(timer_box)
    do_not_move_list.remove(timer_box)
    timer_box = uvage.from_color(screen_width / 2, 35 + postrackery, "white", 300, 40)
    render_list.append(timer_box)
    do_not_move_list.append(timer_box)
    render_list.remove(timer_text)
    do_not_move_list.remove(timer_text)
    timer_text = uvage.from_text(screen_width / 2, 35 + postrackery, "Question time left: " + str(question_time), 30, "black")
    render_list.append(timer_text)
    do_not_move_list.append(timer_text)

# Total timer
# Conversion of time into a mm:ss format
totaltime = starttotaltime
minutes = int (totaltime / 60)
seconds1 = int ((totaltime % 60)/6)
seconds2 = int (totaltime % 10)

totaltimer_text = uvage.from_text(screen_width - 105, 45 + postrackery, "Total time left: " + str(minutes) + ":" + str(seconds1) + str(seconds2), 30, "white")
render_list.append(totaltimer_text)
do_not_move_list.append(totaltimer_text)

def total_timer():
    global add_timer
    global totaltime
    global totaltimer_text
    global minutes
    global seconds1
    global seconds2
    if add_timer:
        if totaltime > 0:  # Ensure the timer doesn't go below 0
            totaltime -= 1
            minutes = int(totaltime / 60)
            seconds1 = int((totaltime % 60) / 10)
            seconds2 = int(totaltime % 10)

    render_list.remove(totaltimer_text)
    do_not_move_list.remove(totaltimer_text)
    totaltimer_text = uvage.from_text(screen_width - 105, 45 + postrackery,
                                      "Total time left: " + str(minutes) + ":" + str(seconds1) + str(seconds2), 30,
                                      "white")
    render_list.append(totaltimer_text)
    do_not_move_list.append(totaltimer_text)


# Game over
gameover = False
def gameovercheck():
    global gameover
    global render_list
    global boundaries_list
    global do_not_move_list
    global blocks
    global totaltime
    if len(blocks) <= 0 or totaltime <= 0:
        gameover = True
    if gameover:
        render_list = []
        do_not_move_list = []
        camera.draw("Game Over!", 72, "white", screen_width / 2, (screen_height / 2 - 100))
        camera.draw ("Your final tower height was: " + str(score), 36, "white", screen_width / 2, (screen_height / 2 - 50))
        restart_game_button = uvage.from_color(screen_width / 2, (screen_height / 2) + postrackery, "white", 300, 50)
        camera.draw(restart_game_button)
        camera.draw("Restart game", 48, "black", screen_width / 2, (screen_height / 2))
        return True

# Restart from game over
restartbuttonycordlower = int(screen_height/2 -25)
restartbuttonycordupper = int(screen_height/2 +25)

def restart():
    global restartbuttonycordlower
    global restartbuttonycordupper
    global postrackery
    if camera.mouseclick:
        mouseposition = camera.mouse
        mousex = int(mouseposition[0])
        mousey = int(mouseposition[1])
        if (mousex in range (int(screen_width/2 -150), int(screen_width/2 +150))) and (mousey in range (int(restartbuttonycordlower + postrackery), int(restartbuttonycordupper + postrackery))):
            camera.draw("Check!", 72, "red", 100, 100)
            global block1
            global block2
            global question1
            global currentquestion
            global gameover
            global score
            global restart_game_button
            global boundaries_list
            global totaltime
            gameover = False
            boundaries_list = []
            lower_boundary = uvage.from_color(screen_width / 2, screen_height + 5000, "brown", screen_width + 10, 10000)
            boundaries_list.append(lower_boundary)
            left_boundary = uvage.from_color(-50, screen_height / 2, "dodgerblue3", 100, screen_height + 10)
            boundaries_list.append(left_boundary)
            right_boundary = uvage.from_color(screen_width + 50, screen_height / 2, "dodgerblue3", 100, screen_height + 10)
            boundaries_list.append(right_boundary)
            restartbuttonycordlower = screen_height / 2 - 25
            restartbuttonycordupper = screen_height / 2 + 25
            totaltime = starttotaltime
            score = 2
            render_list.append(health_text)
            render_list.append(health_bar_overlay)
            render_list.append(health_bar)
            render_list.append(score_text)
            render_list.append(timer_box)
            render_list.append(timer_text)
            render_list.append(totaltimer_text)
            do_not_move_list.append(health_text)
            do_not_move_list.append(health_bar_overlay)
            do_not_move_list.append(health_bar)
            do_not_move_list.append(score_text)
            do_not_move_list.append(timer_box)
            do_not_move_list.append(timer_text)
            do_not_move_list.append(totaltimer_text)
            block1 = Block()
            block2 = Block()
            question1 = Question(random.randint(0, numofquestions-1))
            currentquestion = question1

# Scrolling level
def scroller():
    global restart_game_button
    global restartbuttonycordlower
    global restartbuttonycordupper
    global postrackery
    if uvage.is_pressing("up arrow"):
        camera.move(0, -1*scroll_speed)
        postrackery -= scroll_speed
        for object in do_not_move_list:
            object.y -= scroll_speed
    if uvage.is_pressing("down arrow"):
        camera.move(0, scroll_speed)
        postrackery += scroll_speed
        for object in do_not_move_list:
            object.y += scroll_speed

# Other graphics: Block graphics, multicolored answer boxes, side characters
# Grass texture:
grass = uvage.from_image(screen_width/2, screen_width*1.22, "Pink Grass Block.png")
grass.width = screen_width
background_list.append(grass)

# Meter to measure how high things are going
meter = uvage.from_image(175, screen_height-(block_height * 104/2)+93, "meter.png")
meter.height = block_height*104*0.96
background_list.append(meter)

# Trivia tower logo
logo = uvage.from_image(screen_width-175, screen_width/3, "Trivia Tower Logo.png")
logo.width = 200
background_list.append(logo)

# Tutorial text
tutorialtext = uvage.from_image(screen_width-175, 4*screen_width/7, "tutorialtext.png")
tutorialtext.width = 200
background_list.append(tutorialtext)

# Clouds graphics
clouds_list = []
cloud_timer_count = 0
cloud_on_which = 0
cloud_add_timer = False
cloudanimations = uvage.load_sprite_sheet("Cloud Sprite Sheet.png", 1, 5)
cloud1 = uvage.from_image(100, 200, cloudanimations[-1])
cloud1.width = 300
clouds_list.append(cloud1)
cloud2 = uvage.from_image(screen_width/2, -400, cloudanimations[-1])
cloud2.width = 300
clouds_list.append(cloud2)
cloud3 = uvage.from_image(screen_width/2+200, -900, cloudanimations[-1])
cloud3.width = 300
clouds_list.append(cloud3)
cloud4 = uvage.from_image(screen_width/2-200, -1500, cloudanimations[-1])
cloud4.width = 300
clouds_list.append(cloud4)
cloud5 = uvage.from_image(screen_width/2+150, -1800, cloudanimations[-1])
cloud5.width = 300
clouds_list.append(cloud5)
cloud6 = uvage.from_image(screen_width/2-100, -1300, cloudanimations[-1])
cloud6.width = 300
clouds_list.append(cloud6)
cloud7 = uvage.from_image(screen_width/2+200, -2000, cloudanimations[-1])
cloud7.width = 300
clouds_list.append(cloud7)
cloud8 = uvage.from_image(screen_width/2-200, -3000, cloudanimations[-1])
cloud8.width = 300
clouds_list.append(cloud8)
cloud9 = uvage.from_image(screen_width/2+150, -2800, cloudanimations[-1])
cloud9.width = 300
clouds_list.append(cloud9)
cloud10 = uvage.from_image(screen_width/2-100, -4000, cloudanimations[-1])
cloud10.width = 300
clouds_list.append(cloud10)
cloud11 = uvage.from_image(screen_width/2+200, -5000, cloudanimations[-1])
cloud11.width = 300
clouds_list.append(cloud11)


def cloudloop():
    global cloud_add_timer
    global cloud_timer_count
    if cloud_timer_count == fps/3:
        cloud_add_timer = True
        cloud_timer_count = 0
    else:
        cloud_timer_count += 1
        cloud_add_timer = False

def cloudanimate():
    global cloud_add_timer
    global clouds_list
    global cloudanimations
    global cloud_on_which
    if cloud_add_timer:
        if cloud_on_which < 4:
            for object in clouds_list:
              object.image = cloudanimations[cloud_on_which]
            cloud_on_which += 1
        if cloud_on_which == 4:
            for object in clouds_list:
              object.image = cloudanimations[cloud_on_which]
            cloud_on_which = 0

# Cats and other sprites
cats_list = []
cat_on_which = 0
catanimations = uvage.load_sprite_sheet("Cat sprite sheet.png", 5, 5)

cat1 = uvage.from_image(screen_width/2-300, -200, catanimations[-1])
cat1.width = 100
cats_list.append(cat1)

cat2 = uvage.from_image(screen_width/2+300, -1000, catanimations[-1])
cat2.width = 100
cats_list.append(cat2)

cat3 = uvage.from_image(screen_width/2-170, -2200, catanimations[-1])
cat3.width = 100
cats_list.append(cat3)

cat4 = uvage.from_image(screen_width/2-300, -2700, catanimations[-1])
cat4.width = 100
cats_list.append(cat4)

cat5 = uvage.from_image(screen_width/2+100, -4000, catanimations[-1])
cat5.width = 100
cats_list.append(cat5)

cat6 = uvage.from_image(screen_width/2, -4500, catanimations[-1])
cat6.width = 100
cats_list.append(cat6)

capy_list = []
capy_on_which = 0
capyanimations = uvage.load_sprite_sheet("Capybara.png", 1, 5)

capy1 = uvage.from_image(screen_width/2+300, -700, capyanimations[-1])
capy1.width = 150
capy_list.append(capy1)

capy2 = uvage.from_image(screen_width/2-150, -1400, capyanimations[-1])
capy2.width = 150
capy_list.append(capy2)

capy3 = uvage.from_image(screen_width/2+300, -2400, capyanimations[-1])
capy3.width = 150
capy_list.append(capy3)

capy4 = uvage.from_image(screen_width/2-100, -3700, capyanimations[-1])
capy4.width = 150
capy_list.append(capy4)

capy5 = uvage.from_image(screen_width/2-325, -3300, capyanimations[-1])
capy5.width = 150
capy_list.append(capy5)

capy6 = uvage.from_image(screen_width/2-200, -3270, capyanimations[-1])
capy6.width = 150
capy_list.append(capy6)
def catanimate():
    global cloud_add_timer
    global cats_list
    global catanimations
    global cat_on_which
    if cloud_add_timer:
        if cat_on_which < 24:
            for object in cats_list:
              object.image = catanimations[cat_on_which]
            cat_on_which += 1
        if cat_on_which == 24:
            for object in cats_list:
              object.image = catanimations[cat_on_which]
            cat_on_which = 0

def capyanimate():
    global cloud_add_timer
    global capy_list
    global capyanimations
    global capy_on_which
    if cloud_add_timer:
        if capy_on_which < 4:
            for object in capy_list:
                object.image = capyanimations[capy_on_which]
            capy_on_which += 1
        if capy_on_which == 4:
            for object in capy_list:
                object.image = capyanimations[capy_on_which]
            capy_on_which = 0


# Valentine's Day Graphics
# Valentine's Day Text
vdaytext = uvage.from_image(screen_width-175, 4*screen_width/7 -290, "Valentine's Day.png")
vdaytext.width = 200
background_list.append(vdaytext)
# Photos
photo1 = uvage.from_image(screen_width-175, 4*screen_width/7 -400, "photo1.jpg")
photo1.width = 200
background_list.append(photo1)

photo2 = uvage.from_image(screen_width-175, 4*screen_width/7 -800, "photo2.jpg")
photo2.width = 200
background_list.append(photo2)

photo3 = uvage.from_image(screen_width-200, 4*screen_width/7 -1500, "photo3.jpg")
photo3.width = 200
background_list.append(photo3)

photo4 = uvage.from_image(screen_width-150, 4*screen_width/7 -1750, "photo4.jpg")
photo4.width = 200
background_list.append(photo4)

photo5 = uvage.from_image(screen_width-175, 4*screen_width/7 -2000, "photo5.jpg")
photo5.width = 200
background_list.append(photo5)

photo6 = uvage.from_image(screen_width-175, 4*screen_width/7 -2600, "photo6.jpg")
photo6.width = 200
background_list.append(photo6)

photo7 = uvage.from_image(screen_width-130, 4*screen_width/7 -3500, "photo7.jpg")
photo7.width = 200
background_list.append(photo7)

photo8 = uvage.from_image(screen_width-210, 4*screen_width/7 -3900, "photo8.jpg")
photo8.width = 200
background_list.append(photo8)

photo9 = uvage.from_image(screen_width-175, 4*screen_width/7 -4600, "photo9.jpg")
photo9.width = 200
background_list.append(photo9)

photo10 = uvage.from_image(screen_width/2, 4*screen_width/7 -5270, "photo10.jpg")
photo10.width = 500
background_list.append(photo10)

thankyoutext = uvage.from_image(screen_width/2, 4*screen_width/7 -5055, "Thank you message.png")
thankyoutext.width = 400
background_list.append(thankyoutext)
# Other functions

def movement():
    for object in blocks.values():
        if object not in do_not_move_list:
            object.move_speed()

def render_blocks():
    for object in blocks.values():
        camera.draw(object)

def render_others():
    for object in render_list:
        camera.draw(object)

def render_backgrounds():
    for object in background_list:
        camera.draw(object)

def render_clouds():
    for object in clouds_list:
        camera.draw(object)

def render_cats():
    for object in cats_list:
        camera.draw(object)

def render_capys():
    for object in capy_list:
        camera.draw(object)

def boundaries():
    for object in boundaries_list:
        camera.draw(object)
    boundaries_list_new = boundaries_list.copy()
    for object in blocks.values():
        boundaries_list_new.remove(object)
        for each in boundaries_list_new:
            if each != object:
                object.move_to_stop_overlapping(each)
        boundaries_list_new.append(object)

# Tick loop and rendering

block1 = Block ()
block2 = Block ()
question1 = Question (startquestionid)
currentquestion = question1

def tick():
    scroller()
    camera.clear(background_color)
    boundaries()
    render_blocks()
    render_backgrounds()
    cloudloop()
    cloudanimate()
    catanimate()
    capyanimate()
    render_clouds()
    render_cats()
    render_capys()
    if gameovercheck():
        restart()
        camera.display()
        return
    currentquestion.keypress()
    timer_tracker()
    questiontimer()
    total_timer()
    healthtick()
    scoretick()
    gameovercheck()
    render_others()
    movement()
    camera.display()

uvage.timer_loop(fps, tick)

