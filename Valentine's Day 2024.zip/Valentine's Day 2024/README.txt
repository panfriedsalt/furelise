Instructions to run game:
1. Download Python if you haven't already! You can do so by going here: https://www.python.org/downloads/
2. Download pygame using the terminal, inputting in the first line of code on this page:
https://www.pygame.org/wiki/GettingStarted
3. Download PyCharm IDE: https://www.jetbrains.com/pycharm/download/?section=mac.
Brown should have a license for this if you have one for IntelliJ too!
4. Make sure EVERYTHING that came in this package is in one folder! Including the photos :)
5. Open the game.py file in PyCharm, press the green run arrow, and enjoy!